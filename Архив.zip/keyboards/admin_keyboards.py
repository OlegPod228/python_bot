from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

import config
import data_base_api


def approve_moderator_keyboard(post_id):
    post_data = data_base_api.get_post(post_id=post_id)
    moderator_keyboard_markup = InlineKeyboardMarkup()
    approve_moderator_button = InlineKeyboardButton(text=config.buttons_names['approve_moderator_button'], callback_data=f'approve~{post_id}')
    ban_user = InlineKeyboardButton(text=config.buttons_names['ban_user_button_name'], callback_data=f'ban~{post_data["sended_by"]}')
    moderator_keyboard_markup.add(approve_moderator_button)
    moderator_keyboard_markup.add(ban_user)
    return moderator_keyboard_markup


def contact_moderator_keyboard(contact_id):
    contact_data = data_base_api.get_contact(contact_id=contact_id)
    moderator_keyboard_markup = InlineKeyboardMarkup()
    contact_moderator_button = InlineKeyboardButton(text=config.buttons_names['approve_moderator_button'], callback_data=f'contacts~{contact_id}')
    ban_user = InlineKeyboardButton(text=config.buttons_names['ban_user_button_name'], callback_data=f'ban~{contact_data["sended_by"]}')
    moderator_keyboard_markup.add(contact_moderator_button)
    moderator_keyboard_markup.add(ban_user)
    return moderator_keyboard_markup


def content_check(user_id, post_id):
    content_chek_admin = InlineKeyboardMarkup()
    if user_id in config.admins_ids:
        post_data = data_base_api.get_post(post_id=post_id)
        ban_user_button = InlineKeyboardButton(text=config.buttons_names['ban_user_button_name'], callback_data=f'ban~{post_data["sended_by"]}')
        ban_moderator_button = InlineKeyboardButton(text=config.buttons_names['ban_mod_button_name'], callback_data=f'ban~{post_data["moderated_by"]}')
        delete_content_button = InlineKeyboardButton(text=config.buttons_names['delete_post_button_name'], callback_data=f"d~post~{post_id}")
        content_chek_admin.add(ban_user_button)
        content_chek_admin.add(ban_moderator_button)
        content_chek_admin.add(delete_content_button)
        return content_chek_admin
    elif data_base_api.get_user(telegram_id=user_id)['is_moderator']:
        delete_content_button = InlineKeyboardButton(text=config.buttons_names['delete_post_button_name'],
                                                     callback_data=f"d~post~{post_id}")
        content_chek_admin.add(delete_content_button)
        return content_chek_admin


def contact_check(user_id, contact_id):
    content_chek_admin = InlineKeyboardMarkup()
    if user_id in config.admins_ids or user_id == 0:
        post_data = data_base_api.get_contact(contact_id=contact_id)
        ban_user_button = InlineKeyboardButton(text=config.buttons_names['ban_user_button_name'], callback_data=f'ban~{post_data["sended_by"]}')
        ban_moderator_button = InlineKeyboardButton(text=config.buttons_names['ban_mod_button_name'], callback_data=f'ban~{post_data["moderated_by"]}')
        delete_contact_button = InlineKeyboardButton(text=config.buttons_names['delete_post_button_name'], callback_data=f"d~contact~{contact_id}")
        content_chek_admin.add(ban_user_button)
        content_chek_admin.add(ban_moderator_button)
        content_chek_admin.add(delete_contact_button)
        return content_chek_admin
    elif data_base_api.get_user(telegram_id=user_id)['is_moderator']:
        delete_contact_button = InlineKeyboardButton(text=config.buttons_names['delete_post_button_name'],
                                                     callback_data=f"d~contact~{contact_id}")

        content_chek_admin.add(delete_contact_button)
        return content_chek_admin


def add_moderator_keyboard(user_id):
    add_moderator_keyboard_markup = InlineKeyboardMarkup()
    approve_moderator = InlineKeyboardButton(text=config.buttons_names['approve_moderator_button_name'],
                                             callback_data=f'add_moder~{user_id}')
    add_moderator_keyboard_markup.insert(approve_moderator)
    return add_moderator_keyboard_markup